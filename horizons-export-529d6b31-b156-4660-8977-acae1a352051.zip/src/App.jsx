
    import React, { useState, useEffect } from 'react';
    import { motion, AnimatePresence } from 'framer-motion';
    import { DollarSign, Coins } from 'lucide-react';
    import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
    import { Toaster } from '@/components/ui/toaster';
    import { useToast } from '@/components/ui/use-toast';
    import { useAirdrops } from '@/hooks/useAirdrops';
    import AirdropSelector from '@/components/AirdropSelector';
    import InvestmentTab from '@/components/InvestmentTab';
    import ReturnsTab from '@/components/ReturnsTab';
    import AppHeader from '@/components/AppHeader';
    import AppFooter from '@/components/AppFooter';
    import NoAirdropSelected from '@/components/NoAirdropSelected';
    
    const App = () => {
      const { 
        airdrops, 
        addAirdrop, 
        updateAirdrop, 
        deleteAirdrop, 
        getAirdropById,
        addDailyLog,
        updateDailyLog,
        deleteDailyLog,
        addToken,
        updateToken,
        deleteToken,
        calculateAirdropAnalytics,
        isLoading 
      } = useAirdrops();
      const { toast } = useToast();
      const [selectedAirdropId, setSelectedAirdropId] = useState(null);
      const [currentAirdrop, setCurrentAirdrop] = useState(null);
      
      const [isAirdropModalOpen, setIsAirdropModalOpen] = useState(false);
      const [airdropName, setAirdropName] = useState('');

      const [isDailyLogModalOpen, setIsDailyLogModalOpen] = useState(false);
      const [dailyLogData, setDailyLogData] = useState({ points: '', ranking: '' });
      const [editingDailyLog, setEditingDailyLog] = useState(null);

      const [isTokenModalOpen, setIsTokenModalOpen] = useState(false);
      const [tokenData, setTokenData] = useState({ quantity: '', saleValue: '' });
      const [editingToken, setEditingToken] = useState(null);

      useEffect(() => {
        if (selectedAirdropId) {
          setCurrentAirdrop(getAirdropById(selectedAirdropId));
        } else {
          setCurrentAirdrop(null);
        }
      }, [selectedAirdropId, airdrops, getAirdropById]);

      const handleAddAirdrop = async () => {
        if (airdropName.trim() === '') {
          toast({ title: "Erro", description: "O nome do airdrop não pode estar vazio.", variant: "destructive" });
          return;
        }
        const newId = await addAirdrop(airdropName);
        if (newId) {
          setSelectedAirdropId(newId);
          setAirdropName('');
          setIsAirdropModalOpen(false);
          toast({ title: "Sucesso", description: "Airdrop adicionado!" });
        } else {
           toast({ title: "Erro", description: "Falha ao adicionar airdrop.", variant: "destructive" });
        }
      };

      const handleUpdateAirdropField = (field, value) => {
        if (currentAirdrop) {
          const updatedData = { ...currentAirdrop, [field]: value };
          updateAirdrop(currentAirdrop.id, updatedData);
          toast({ title: "Atualizado", description: `${field} atualizado.`});
        }
      };
      
      const handleDeleteAirdrop = async () => {
        if (currentAirdrop) {
          await deleteAirdrop(currentAirdrop.id);
          setSelectedAirdropId(null);
          toast({ title: "Deletado", description: "Airdrop removido.", variant: "destructive" });
        }
      };

      const handleAddOrUpdateDailyLog = async () => {
        if (!currentAirdrop) return;
        if (editingDailyLog) {
          await updateDailyLog(currentAirdrop.id, editingDailyLog.id, dailyLogData);
          toast({ title: "Sucesso", description: "Registro diário atualizado!" });
        } else {
          await addDailyLog(currentAirdrop.id, dailyLogData);
          toast({ title: "Sucesso", description: "Registro diário adicionado!" });
        }
        setDailyLogData({ points: '', ranking: '' });
        setEditingDailyLog(null);
        setIsDailyLogModalOpen(false);
      };

      const openEditDailyLogModal = (log) => {
        setEditingDailyLog(log);
        setDailyLogData({ points: log.points, ranking: log.ranking });
        setIsDailyLogModalOpen(true);
      };

      const handleDeleteDailyLog = async (logId) => {
        if (currentAirdrop) {
          await deleteDailyLog(currentAirdrop.id, logId);
          toast({ title: "Deletado", description: "Registro diário removido.", variant: "destructive" });
        }
      };

      const handleAddOrUpdateToken = async () => {
        if (!currentAirdrop) return;
        if (editingToken) {
          await updateToken(currentAirdrop.id, editingToken.id, tokenData);
          toast({ title: "Sucesso", description: "Token atualizado!" });
        } else {
          await addToken(currentAirdrop.id, tokenData);
          toast({ title: "Sucesso", description: "Token adicionado!" });
        }
        setTokenData({ quantity: '', saleValue: '' });
        setEditingToken(null);
        setIsTokenModalOpen(false);
      };

      const openEditTokenModal = (token) => {
        setEditingToken(token);
        setTokenData({ quantity: token.quantity, saleValue: token.saleValue });
        setIsTokenModalOpen(true);
      };

      const handleDeleteToken = async (tokenId) => {
        if (currentAirdrop) {
          await deleteToken(currentAirdrop.id, tokenId);
          toast({ title: "Deletado", description: "Token removido.", variant: "destructive" });
        }
      };

      const analytics = currentAirdrop ? calculateAirdropAnalytics(currentAirdrop) : {};

      if (isLoading && (!airdrops || airdrops.length === 0) && !selectedAirdropId) {
        return <div className="flex items-center justify-center min-h-screen bg-background text-foreground">Carregando dados do Firebase...</div>;
      }

      return (
        <div className="min-h-screen bg-gradient-to-br from-[#1A1B26] to-[#2C2D3A] p-4 sm:p-8 text-foreground">
          <Toaster />
          <AppHeader />

          <AirdropSelector
            airdrops={airdrops}
            selectedAirdropId={selectedAirdropId}
            setSelectedAirdropId={setSelectedAirdropId}
            isAirdropModalOpen={isAirdropModalOpen}
            setIsAirdropModalOpen={setIsAirdropModalOpen}
            airdropName={airdropName}
            setAirdropName={setAirdropName}
            handleAddAirdrop={handleAddAirdrop}
            handleDeleteAirdrop={handleDeleteAirdrop}
            currentAirdrop={currentAirdrop}
          />
          
          <AnimatePresence mode="wait">
            {currentAirdrop ? (
              <motion.div
                key={currentAirdrop.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
              >
                <Tabs defaultValue="investment" className="w-full">
                  <TabsList className="grid w-full grid-cols-2 bg-muted/50 border-border shadow-md">
                    <TabsTrigger value="investment" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-lg transition-all">
                      <DollarSign className="mr-2 h-5 w-5" /> Investimento
                    </TabsTrigger>
                    <TabsTrigger value="returns" className="data-[state=active]:bg-secondary data-[state=active]:text-secondary-foreground data-[state=active]:shadow-lg transition-all">
                      <Coins className="mr-2 h-5 w-5" /> Retornos
                    </TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="investment">
                    <InvestmentTab
                      currentAirdrop={currentAirdrop}
                      handleUpdateAirdropField={handleUpdateAirdropField}
                      isDailyLogModalOpen={isDailyLogModalOpen}
                      setIsDailyLogModalOpen={setIsDailyLogModalOpen}
                      editingDailyLog={editingDailyLog}
                      setEditingDailyLog={setEditingDailyLog}
                      dailyLogData={dailyLogData}
                      setDailyLogData={setDailyLogData}
                      handleAddOrUpdateDailyLog={handleAddOrUpdateDailyLog}
                      openEditDailyLogModal={openEditDailyLogModal}
                      handleDeleteDailyLog={handleDeleteDailyLog}
                    />
                  </TabsContent>

                  <TabsContent value="returns">
                    <ReturnsTab
                      currentAirdrop={currentAirdrop}
                      handleUpdateAirdropField={handleUpdateAirdropField}
                      isTokenModalOpen={isTokenModalOpen}
                      setIsTokenModalOpen={setIsTokenModalOpen}
                      editingToken={editingToken}
                      setEditingToken={setEditingToken}
                      tokenData={tokenData}
                      setTokenData={setTokenData}
                      handleAddOrUpdateToken={handleAddOrUpdateToken}
                      openEditTokenModal={openEditTokenModal}
                      handleDeleteToken={handleDeleteToken}
                      analytics={analytics}
                    />
                  </TabsContent>
                </Tabs>
              </motion.div>
            ) : (
              <NoAirdropSelected isLoading={isLoading} />
            )}
          </AnimatePresence>
          <AppFooter />
        </div>
      );
    };

    export default App;
  