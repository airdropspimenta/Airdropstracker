
    import React from 'react';
    import { PlusCircle, Trash2 } from 'lucide-react';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent } from '@/components/ui/card';
    import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';

    const AirdropSelector = ({
      airdrops,
      selectedAirdropId,
      setSelectedAirdropId,
      isAirdropModalOpen,
      setIsAirdropModalOpen,
      airdropName,
      setAirdropName,
      handleAddAirdrop,
      handleDeleteAirdrop,
      currentAirdrop
    }) => {
      return (
        <Card className="mb-8 bg-card/80 backdrop-blur-sm border-border shadow-2xl">
          <CardContent className="p-6 flex flex-col sm:flex-row items-center gap-4">
            <div className="flex-grow w-full sm:w-auto">
              <Select onValueChange={setSelectedAirdropId} value={selectedAirdropId || ""}>
                <SelectTrigger className="w-full sm:w-[280px] bg-input border-border text-foreground">
                  <SelectValue placeholder="Selecione um airdrop" />
                </SelectTrigger>
                <SelectContent className="bg-popover border-border">
                  {airdrops.map((ad) => (
                    <SelectItem key={ad.id} value={ad.id} className="hover:bg-accent focus:bg-accent">
                      {ad.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Dialog open={isAirdropModalOpen} onOpenChange={setIsAirdropModalOpen}>
              <DialogTrigger asChild>
                <Button className="w-full sm:w-auto bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-600/90 text-primary-foreground shadow-lg transition-transform hover:scale-105">
                  <PlusCircle className="mr-2 h-5 w-5" /> Novo Airdrop
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[425px] bg-card border-border">
                <DialogHeader>
                  <DialogTitle>Novo Airdrop</DialogTitle>
                  <DialogDescription>Insira o nome para o seu novo airdrop.</DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <Label htmlFor="airdropName" className="text-left">Nome do Airdrop</Label>
                  <Input id="airdropName" value={airdropName} onChange={(e) => setAirdropName(e.target.value)} className="bg-input border-border" />
                </div>
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setIsAirdropModalOpen(false)}>Cancelar</Button>
                  <Button type="submit" onClick={handleAddAirdrop}>Adicionar</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
            {currentAirdrop && (
               <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive" className="w-full sm:w-auto shadow-lg transition-transform hover:scale-105">
                    <Trash2 className="mr-2 h-5 w-5" /> Excluir Airdrop
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent className="bg-card border-border">
                  <AlertDialogHeader>
                    <AlertDialogTitle>Você tem certeza?</AlertDialogTitle>
                    <AlertDialogDescription>
                      Esta ação não pode ser desfeita. Isso excluirá permanentemente o airdrop e todos os seus dados.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                    <AlertDialogAction onClick={handleDeleteAirdrop}>Excluir</AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            )}
          </CardContent>
        </Card>
      );
    };

    export default AirdropSelector;
  