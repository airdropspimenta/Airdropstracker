
    import React from 'react';

    const AppFooter = () => {
      return (
        <footer className="text-center mt-12 py-6 border-t border-border/50">
          <p className="text-sm text-muted-foreground">&copy; {new Date().getFullYear()} Airdrop Tracker Pro. Todos os direitos reservados.</p>
          <p className="text-xs text-muted-foreground/70 mt-1">Desenvolvido com ❤️ por Hostinger Horizons</p>
        </footer>
      );
    };

    export default AppFooter;
  