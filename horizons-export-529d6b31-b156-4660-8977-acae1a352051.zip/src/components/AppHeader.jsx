
    import React from 'react';

    const AppHeader = () => {
      return (
        <header className="text-center mb-12">
          <h1 className="text-5xl font-bold gradient-text">
            Airdrop Tracker Pro
          </h1>
          <p className="text-muted-foreground mt-2 text-lg">Monitore seus ganhos com airdrops de forma eficiente.</p>
        </header>
      );
    };

    export default AppHeader;
  