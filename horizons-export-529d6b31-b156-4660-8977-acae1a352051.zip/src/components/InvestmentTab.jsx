
    import React from 'react';
    import { motion } from 'framer-motion';
    import { PlusCircle, Edit, Trash } from 'lucide-react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
    import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
    import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';

    const cardVariants = {
      hidden: { opacity: 0, y: 20 },
      visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
    };
    const MotionCard = motion(Card);

    const InvestmentTab = ({
      currentAirdrop,
      handleUpdateAirdropField,
      isDailyLogModalOpen,
      setIsDailyLogModalOpen,
      editingDailyLog,
      setEditingDailyLog,
      dailyLogData,
      setDailyLogData,
      handleAddOrUpdateDailyLog,
      openEditDailyLogModal,
      handleDeleteDailyLog
    }) => {
      return (
        <MotionCard variants={cardVariants} initial="hidden" animate="visible" className="bg-card/80 backdrop-blur-sm border-border shadow-xl">
          <CardHeader>
            <CardTitle className="text-2xl gradient-text">Informações do Investimento</CardTitle>
            <CardDescription>Gerencie seus investimentos e acompanhe o progresso diário.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="capitalApplied">Capital Aplicado (USD)</Label>
                <Input id="capitalApplied" type="number" placeholder="Ex: 100" value={currentAirdrop.capitalApplied || ''} onChange={(e) => handleUpdateAirdropField('capitalApplied', e.target.value)} className="bg-input border-border" />
              </div>
              <div>
                <Label htmlFor="totalFees">Total de Taxas (USD)</Label>
                <Input id="totalFees" type="number" placeholder="Ex: 10" value={currentAirdrop.totalFees || ''} onChange={(e) => handleUpdateAirdropField('totalFees', e.target.value)} className="bg-input border-border" />
              </div>
              <div>
                <Label htmlFor="startDate">Data de Início</Label>
                <Input id="startDate" type="date" value={currentAirdrop.startDate || ''} onChange={(e) => handleUpdateAirdropField('startDate', e.target.value)} className="bg-input border-border" />
              </div>
              <div>
                <Label htmlFor="endDate">Data de Término (Possível)</Label>
                <Input id="endDate" type="date" value={currentAirdrop.endDate || ''} onChange={(e) => handleUpdateAirdropField('endDate', e.target.value)} className="bg-input border-border" />
              </div>
            </div>
            
            <div className="mt-6">
              <div className="flex justify-between items-center mb-4">
                <h4 className="text-xl font-semibold gradient-text">Registro Diário</h4>
                <Dialog open={isDailyLogModalOpen} onOpenChange={(isOpen) => { setIsDailyLogModalOpen(isOpen); if(!isOpen) setEditingDailyLog(null); }}>
                  <DialogTrigger asChild>
                    <Button size="sm" className="bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-600/90 text-primary-foreground shadow-md">
                      <PlusCircle className="mr-2 h-4 w-4" /> {editingDailyLog ? "Editar Registro" : "Adicionar Registro"}
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[425px] bg-card border-border">
                    <DialogHeader>
                      <DialogTitle>{editingDailyLog ? "Editar Registro Diário" : "Novo Registro Diário"}</DialogTitle>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                      <div>
                        <Label htmlFor="points">Pontos Recebidos</Label>
                        <Input id="points" type="number" placeholder="Ex: 1000" value={dailyLogData.points} onChange={(e) => setDailyLogData({...dailyLogData, points: e.target.value})} className="bg-input border-border" />
                      </div>
                      <div>
                        <Label htmlFor="ranking">Posição no Ranking</Label>
                        <Input id="ranking" type="number" placeholder="Ex: 500" value={dailyLogData.ranking} onChange={(e) => setDailyLogData({...dailyLogData, ranking: e.target.value})} className="bg-input border-border" />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button type="button" variant="outline" onClick={() => {setIsDailyLogModalOpen(false); setEditingDailyLog(null);}}>Cancelar</Button>
                      <Button onClick={handleAddOrUpdateDailyLog}>{editingDailyLog ? "Salvar Alterações" : "Adicionar"}</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
              {currentAirdrop.dailyLogs && currentAirdrop.dailyLogs.length > 0 ? (
                <Table className="border-border">
                  <TableHeader>
                    <TableRow className="border-border">
                      <TableHead>Data</TableHead>
                      <TableHead>Pontos</TableHead>
                      <TableHead>Ranking</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {currentAirdrop.dailyLogs.sort((a,b) => new Date(b.date) - new Date(a.date)).map((log) => (
                      <TableRow key={log.id} className="border-border hover:bg-muted/30">
                        <TableCell>{new Date(log.date).toLocaleDateString()}</TableCell>
                        <TableCell>{log.points}</TableCell>
                        <TableCell>{log.ranking}</TableCell>
                        <TableCell className="text-right space-x-2">
                          <Button variant="ghost" size="icon" onClick={() => openEditDailyLogModal(log)} className="hover:text-primary">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="ghost" size="icon" className="hover:text-destructive">
                                <Trash className="h-4 w-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent className="bg-card border-border">
                              <AlertDialogHeader><AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle></AlertDialogHeader>
                              <AlertDialogDescription>Tem certeza que deseja excluir este registro diário?</AlertDialogDescription>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                <AlertDialogAction onClick={() => handleDeleteDailyLog(log.id)}>Excluir</AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <p className="text-muted-foreground text-center py-4">Nenhum registro diário adicionado.</p>
              )}
            </div>
          </CardContent>
        </MotionCard>
      );
    };
    
    export default InvestmentTab;
  