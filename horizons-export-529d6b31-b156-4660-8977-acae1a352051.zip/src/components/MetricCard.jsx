
    import React from 'react';
    import { motion } from 'framer-motion';
    import { cn } from '@/lib/utils';

    const cardVariants = {
      hidden: { opacity: 0, y: 20 },
      visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
    };

    const MetricCard = ({ icon, title, value, valueColor = 'text-foreground' }) => (
      <motion.div 
        variants={cardVariants} 
        className="bg-card/50 backdrop-blur-sm p-4 shadow-lg hover:shadow-primary/20 transition-shadow rounded-lg"
      >
        <div className="flex flex-row items-center justify-between space-y-0 pb-2">
          <h3 className="text-sm font-medium text-muted-foreground">{title}</h3>
          {React.cloneElement(icon, { className: cn("h-5 w-5 text-muted-foreground", valueColor === 'text-green-400' ? 'text-green-400' : valueColor === 'text-red-400' ? 'text-red-400' : 'text-primary') })}
        </div>
        <div>
          <div className={cn("text-2xl font-bold", valueColor)}>{value}</div>
        </div>
      </motion.div>
    );

    export default MetricCard;
  