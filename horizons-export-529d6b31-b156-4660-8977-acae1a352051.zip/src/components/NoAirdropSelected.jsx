
    import React from 'react';
    import { motion } from 'framer-motion';

    const NoAirdropSelected = ({ isLoading }) => {
      return (
        <motion.div
          key="no-selection"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="text-center py-20"
        >
          <img  class="mx-auto mb-8 w-48 h-48 opacity-50" alt="Ícone de foguete aguardando seleção" src="https://images.unsplash.com/photo-1639843885527-43b098a9661a" />
          <h2 className="text-3xl font-semibold mb-4 gradient-text">Nenhum Airdrop Selecionado</h2>
          <p className="text-muted-foreground text-lg">Selecione um airdrop na lista acima ou crie um novo para começar.</p>
          {isLoading && <p className="text-sm text-primary mt-4">Sincronizando com a nuvem...</p>}
        </motion.div>
      );
    };

    export default NoAirdropSelected;
  