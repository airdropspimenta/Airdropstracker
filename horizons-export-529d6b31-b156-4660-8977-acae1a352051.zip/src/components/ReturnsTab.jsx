
    import React from 'react';
    import { motion } from 'framer-motion';
    import { PlusCircle, Edit, Trash, DollarSign, TrendingUp, TrendingDown, BarChart, ListChecks } from 'lucide-react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
    import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
    import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
    import MetricCard from '@/components/MetricCard';

    const cardVariants = {
      hidden: { opacity: 0, y: 20 },
      visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
    };
    const MotionCard = motion(Card);
    
    const ReturnsTab = ({
      currentAirdrop,
      handleUpdateAirdropField,
      isTokenModalOpen,
      setIsTokenModalOpen,
      editingToken,
      setEditingToken,
      tokenData,
      setTokenData,
      handleAddOrUpdateToken,
      openEditTokenModal,
      handleDeleteToken,
      analytics
    }) => {
      return (
        <MotionCard variants={cardVariants} initial="hidden" animate="visible" className="bg-card/80 backdrop-blur-sm border-border shadow-xl">
          <CardHeader>
            <CardTitle className="text-2xl gradient-text">Retornos e Análises</CardTitle>
            <CardDescription>Acompanhe seus retornos e analise o desempenho.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label htmlFor="capitalWithdrawn">Capital Retirado (USD)</Label>
              <Input id="capitalWithdrawn" type="number" placeholder="Ex: 50" value={currentAirdrop.capitalWithdrawn || ''} onChange={(e) => handleUpdateAirdropField('capitalWithdrawn', e.target.value)} className="bg-input border-border" />
            </div>

            <div className="mt-6">
              <div className="flex justify-between items-center mb-4">
                <h4 className="text-xl font-semibold gradient-text">Tokens Recebidos</h4>
                 <Dialog open={isTokenModalOpen} onOpenChange={(isOpen) => { setIsTokenModalOpen(isOpen); if(!isOpen) setEditingToken(null); }}>
                  <DialogTrigger asChild>
                    <Button size="sm" className="bg-gradient-to-r from-secondary to-teal-600 hover:from-secondary/90 hover:to-teal-600/90 text-secondary-foreground shadow-md">
                      <PlusCircle className="mr-2 h-4 w-4" /> {editingToken ? "Editar Token" : "Adicionar Token"}
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[425px] bg-card border-border">
                    <DialogHeader>
                      <DialogTitle>{editingToken ? "Editar Token" : "Novo Token Recebido"}</DialogTitle>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                      <div>
                        <Label htmlFor="tokenQuantity">Quantidade</Label>
                        <Input id="tokenQuantity" type="number" placeholder="Ex: 100" value={tokenData.quantity} onChange={(e) => setTokenData({...tokenData, quantity: e.target.value})} className="bg-input border-border" />
                      </div>
                      <div>
                        <Label htmlFor="tokenSaleValue">Valor de Venda (USD)</Label>
                        <Input id="tokenSaleValue" type="number" placeholder="Ex: 0.5" value={tokenData.saleValue} onChange={(e) => setTokenData({...tokenData, saleValue: e.target.value})} className="bg-input border-border" />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button type="button" variant="outline" onClick={() => {setIsTokenModalOpen(false); setEditingToken(null);}}>Cancelar</Button>
                      <Button onClick={handleAddOrUpdateToken}>{editingToken ? "Salvar Alterações" : "Adicionar"}</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
              {currentAirdrop.tokens && currentAirdrop.tokens.length > 0 ? (
                <Table className="border-border">
                  <TableHeader>
                    <TableRow className="border-border">
                      <TableHead>Quantidade</TableHead>
                      <TableHead>Valor Venda (USD)</TableHead>
                      <TableHead>Total (USD)</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {currentAirdrop.tokens.map((token) => (
                      <TableRow key={token.id} className="border-border hover:bg-muted/30">
                        <TableCell>{token.quantity}</TableCell>
                        <TableCell>{parseFloat(token.saleValue || 0).toFixed(2)}</TableCell>
                        <TableCell>{(parseFloat(token.quantity || 0) * parseFloat(token.saleValue || 0)).toFixed(2)}</TableCell>
                        <TableCell className="text-right space-x-2">
                          <Button variant="ghost" size="icon" onClick={() => openEditTokenModal(token)} className="hover:text-secondary">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="ghost" size="icon" className="hover:text-destructive">
                                <Trash className="h-4 w-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent className="bg-card border-border">
                              <AlertDialogHeader><AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle></AlertDialogHeader>
                              <AlertDialogDescription>Tem certeza que deseja excluir este token?</AlertDialogDescription>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                <AlertDialogAction onClick={() => handleDeleteToken(token.id)}>Excluir</AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <p className="text-muted-foreground text-center py-4">Nenhum token adicionado.</p>
              )}
            </div>

            <div className="mt-8 pt-6 border-t border-border">
              <h4 className="text-xl font-semibold mb-4 gradient-text">Resultados Financeiros e Métricas</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <MetricCard icon={<DollarSign />} title="Total Vendido (USD)" value={`$${analytics.totalTokenValueSold?.toFixed(2) || '0.00'}`} />
                <MetricCard icon={analytics.profitOrLoss >= 0 ? <TrendingUp /> : <TrendingDown />} title="Lucro/Prejuízo (USD)" value={`$${analytics.profitOrLoss?.toFixed(2) || '0.00'}`} valueColor={analytics.profitOrLoss >= 0 ? 'text-green-400' : 'text-red-400'} />
                <MetricCard icon={<BarChart />} title="ROI Percentual" value={`${analytics.roi?.toFixed(2) || '0.00'}%`} valueColor={analytics.roi >= 0 ? 'text-green-400' : 'text-red-400'} />
                <MetricCard icon={<ListChecks />} title="Média Diária de Pontos" value={analytics.averageDailyPoints?.toFixed(2) || '0.00'} />
                <MetricCard icon={analytics.rankingChange > 0 ? <TrendingUp /> : analytics.rankingChange < 0 ? <TrendingDown /> : <BarChart />} title="Variação Ranking (vs dia anterior)" value={`${analytics.rankingChange > 0 ? '+' : ''}${analytics.rankingChange || '0'}`} valueColor={analytics.rankingChange > 0 ? 'text-green-400' : analytics.rankingChange < 0 ? 'text-red-400' : 'text-foreground'} />
              </div>
            </div>
          </CardContent>
        </MotionCard>
      );
    };
    
    export default ReturnsTab;
  