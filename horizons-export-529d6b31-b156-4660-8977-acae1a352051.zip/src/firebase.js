
    import { initializeApp } from "firebase/app";
    import { getFirestore } from "firebase/firestore";

    const firebaseConfig = {
      apiKey: "AIzaSyCB1pAOmsCjNt3LMwM6AoypfBp4igV-Ul8",
      authDomain: "airdropstracker-70da0.firebaseapp.com",
      projectId: "airdropstracker-70da0",
      storageBucket: "airdropstracker-70da0.firebasestorage.app",
      messagingSenderId: "134373939524",
      appId: "1:134373939524:web:44453319fcec820473df11",
      measurementId: "G-M7XH3TKK4D"
    };

    const app = initializeApp(firebaseConfig);
    const db = getFirestore(app);

    export { db };
  