
    import { useState, useEffect, useCallback } from 'react';
    import { v4 as uuidv4 } from 'uuid';
    import { db } from '@/firebase';
    import { collection, getDocs, doc, setDoc, deleteDoc, writeBatch, query, where, getDoc } from 'firebase/firestore';

    const initialAirdropData = {
      capitalApplied: 0,
      startDate: '',
      endDate: '',
      totalFees: 0,
      dailyLogs: [],
      capitalWithdrawn: 0,
      tokens: [],
    };

    export function useAirdrops() {
      const [airdrops, setAirdrops] = useState([]);
      const [isLoading, setIsLoading] = useState(true);
      const airdropsCollectionRef = collection(db, "airdrops");

      const fetchAirdrops = useCallback(async () => {
        setIsLoading(true);
        try {
          const data = await getDocs(airdropsCollectionRef);
          const fetchedAirdrops = data.docs.map((doc) => ({ ...doc.data(), id: doc.id }));
          
          const airdropsWithSubcollections = await Promise.all(fetchedAirdrops.map(async (ad) => {
            const dailyLogsCollectionRef = collection(db, "airdrops", ad.id, "dailyLogs");
            const dailyLogsSnap = await getDocs(dailyLogsCollectionRef);
            const dailyLogs = dailyLogsSnap.docs.map(logDoc => ({ ...logDoc.data(), id: logDoc.id }));
            
            const tokensCollectionRef = collection(db, "airdrops", ad.id, "tokens");
            const tokensSnap = await getDocs(tokensCollectionRef);
            const tokens = tokensSnap.docs.map(tokenDoc => ({ ...tokenDoc.data(), id: tokenDoc.id }));
            
            return { ...ad, dailyLogs, tokens };
          }));

          setAirdrops(airdropsWithSubcollections);
        } catch (error) {
          console.error("Failed to load airdrops from Firestore", error);
          setAirdrops([]);
        }
        setIsLoading(false);
      }, []);


      useEffect(() => {
        fetchAirdrops();
      }, [fetchAirdrops]);


      const addAirdrop = async (name) => {
        setIsLoading(true);
        const id = uuidv4();
        const newAirdrop = {
          id,
          name,
          ...initialAirdropData,
          dailyLogs: [],
          tokens: [],
        };
        try {
          await setDoc(doc(db, "airdrops", id), {name: newAirdrop.name, capitalApplied: newAirdrop.capitalApplied, startDate: newAirdrop.startDate, endDate: newAirdrop.endDate, totalFees: newAirdrop.totalFees, capitalWithdrawn: newAirdrop.capitalWithdrawn });
          await fetchAirdrops(); 
          return id;
        } catch (error) {
          console.error("Error adding airdrop to Firestore: ", error);
          setIsLoading(false);
          return null;
        }
      };
      

      const updateAirdrop = async (id, updatedData) => {
        setIsLoading(true);
        const { dailyLogs, tokens, ...airdropCoreData } = updatedData;
        const airdropDocRef = doc(db, "airdrops", id);
        try {
          await setDoc(airdropDocRef, airdropCoreData, { merge: true });
          await fetchAirdrops();
        } catch (error) {
          console.error("Error updating airdrop in Firestore: ", error);
          setIsLoading(false);
        }
      };
      

      const deleteAirdrop = async (id) => {
        setIsLoading(true);
        const airdropDocRef = doc(db, "airdrops", id);
        try {
          const batch = writeBatch(db);
          
          const dailyLogsCollectionRef = collection(db, "airdrops", id, "dailyLogs");
          const dailyLogsSnap = await getDocs(dailyLogsCollectionRef);
          dailyLogsSnap.docs.forEach(logDoc => batch.delete(logDoc.ref));

          const tokensCollectionRef = collection(db, "airdrops", id, "tokens");
          const tokensSnap = await getDocs(tokensCollectionRef);
          tokensSnap.docs.forEach(tokenDoc => batch.delete(tokenDoc.ref));
          
          batch.delete(airdropDocRef);
          await batch.commit();
          await fetchAirdrops();
        } catch (error) {
          console.error("Error deleting airdrop from Firestore: ", error);
          setIsLoading(false);
        }
      };

      const getAirdropById = (id) => {
        return airdrops.find((ad) => ad.id === id);
      };

      const addDailyLog = async (airdropId, logData) => {
        setIsLoading(true);
        const logId = uuidv4();
        const newLog = { id: logId, date: new Date().toISOString().split('T')[0], ...logData };
        const dailyLogDocRef = doc(db, "airdrops", airdropId, "dailyLogs", logId);
        try {
          await setDoc(dailyLogDocRef, newLog);
          await fetchAirdrops();
        } catch (error) {
          console.error("Error adding daily log to Firestore: ", error);
          setIsLoading(false);
        }
      };
      
      const updateDailyLog = async (airdropId, logId, updatedLogData) => {
        setIsLoading(true);
        const dailyLogDocRef = doc(db, "airdrops", airdropId, "dailyLogs", logId);
        try {
          await setDoc(dailyLogDocRef, updatedLogData, { merge: true });
          await fetchAirdrops();
        } catch (error) {
          console.error("Error updating daily log in Firestore: ", error);
          setIsLoading(false);
        }
      };
      
      const deleteDailyLog = async (airdropId, logId) => {
        setIsLoading(true);
        const dailyLogDocRef = doc(db, "airdrops", airdropId, "dailyLogs", logId);
        try {
          await deleteDoc(dailyLogDocRef);
          await fetchAirdrops();
        } catch (error) {
          console.error("Error deleting daily log from Firestore: ", error);
          setIsLoading(false);
        }
      };

      const addToken = async (airdropId, tokenData) => {
        setIsLoading(true);
        const tokenId = uuidv4();
        const newToken = { id: tokenId, ...tokenData };
        const tokenDocRef = doc(db, "airdrops", airdropId, "tokens", tokenId);
        try {
          await setDoc(tokenDocRef, newToken);
          await fetchAirdrops();
        } catch (error) {
          console.error("Error adding token to Firestore: ", error);
          setIsLoading(false);
        }
      };

      const updateToken = async (airdropId, tokenId, updatedTokenData) => {
        setIsLoading(true);
        const tokenDocRef = doc(db, "airdrops", airdropId, "tokens", tokenId);
        try {
          await setDoc(tokenDocRef, updatedTokenData, { merge: true });
          await fetchAirdrops();
        } catch (error) {
          console.error("Error updating token in Firestore: ", error);
          setIsLoading(false);
        }
      };
      
      const deleteToken = async (airdropId, tokenId) => {
        setIsLoading(true);
        const tokenDocRef = doc(db, "airdrops", airdropId, "tokens", tokenId);
        try {
          await deleteDoc(tokenDocRef);
          await fetchAirdrops();
        } catch (error) {
          console.error("Error deleting token from Firestore: ", error);
          setIsLoading(false);
        }
      };
      
      const calculateAirdropAnalytics = (airdrop) => {
        if (!airdrop) return {};

        const capitalApplied = parseFloat(airdrop.capitalApplied) || 0;
        const totalFees = parseFloat(airdrop.totalFees) || 0;
        const capitalWithdrawn = parseFloat(airdrop.capitalWithdrawn) || 0;
        
        const totalTokenValueSold = (airdrop.tokens || []).reduce((sum, token) => {
            return sum + (parseFloat(token.quantity) || 0) * (parseFloat(token.saleValue) || 0);
        }, 0);

        const totalInvested = capitalApplied + totalFees;
        const netProfitOrLoss = (totalTokenValueSold + capitalWithdrawn) - totalInvested;
        
        const roi = totalInvested > 0 ? (netProfitOrLoss / totalInvested) * 100 : 0;

        const dailyLogs = airdrop.dailyLogs || [];
        const totalPoints = dailyLogs.reduce((sum, log) => sum + (parseFloat(log.points) || 0), 0);
        const averageDailyPoints = dailyLogs.length > 0 ? totalPoints / dailyLogs.length : 0;
        
        let rankingChange = 0;
        if (dailyLogs.length >= 2) {
            const sortedLogs = [...dailyLogs].sort((a, b) => new Date(a.date) - new Date(b.date));
            const lastRank = parseFloat(sortedLogs[sortedLogs.length - 1].ranking) || 0;
            const secondLastRank = parseFloat(sortedLogs[sortedLogs.length - 2].ranking) || 0;
            if (lastRank > 0 && secondLastRank > 0) {
                 rankingChange = secondLastRank - lastRank; 
            }
        }

        return {
            profitOrLoss: netProfitOrLoss,
            roi: roi,
            averageDailyPoints: averageDailyPoints,
            rankingChange: rankingChange,
            totalTokenValueSold: totalTokenValueSold,
        };
      };

      return {
        airdrops,
        isLoading,
        addAirdrop,
        updateAirdrop,
        deleteAirdrop,
        getAirdropById,
        addDailyLog,
        updateDailyLog,
        deleteDailyLog,
        addToken,
        updateToken,
        deleteToken,
        calculateAirdropAnalytics,
      };
    }
  